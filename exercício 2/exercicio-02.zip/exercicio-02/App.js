import React, { useState } from 'react';
import { ScrollView, Image} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

const img1 = require('./assets/crazyDaimond.png');
const img2 = require('./assets/TheWorld.png');
const img3 = require('./assets/KillerQueen.PNG');
const img4 = require('./assets/WhiteSnake.png');
const img5 = require('./assets/StarPlatinum.png');
const img6 = require('./assets/GoldenExperience.png');

export default function App(){

  return(
<SafeAreaProvider>

     <SafeAreaView>
        <ScrollView>
           <Image source={img1} style={{ width: '100%', height: 1000 }} resizeMode="contain" />  //Oi thiago eu usei o contain que permite que a imagem nao fique cortada ok , achei bem util kkkkk 
           <Image source={img2} style={{ width: '100%', height: 1000 }} resizeMode="contain"/>
           <Image source={img3} style={{ width: '100%', height: 1000 }} resizeMode="contain"/>
           <Image source={img4} style={{ width: '100%', height: 1000 }} resizeMode="contain"/>
           <Image source={img5} style={{ width: '100%', height: 1000 }} resizeMode="contain"/>
           <Image source={img6} style={{ width: '100%', height: 1000 }} resizeMode="contain"/>











       </ScrollView>

    </SafeAreaView>

</SafeAreaProvider>

);
}

